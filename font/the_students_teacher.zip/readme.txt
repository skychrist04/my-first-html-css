This font "The Student's Teacher" is created by Francis Fonye.
Co-member of Bitty/Brixdee on http://www.dafont.com/profile.php?user=764521

This font is donationware. You're free to use this font in personal, non-comercial projects. But for any use in a project where you or a client benefit monetarily, we require you to spread the bread around and make a dontation. You can do this by making a payment to https://www.paypal.me/FrancisBrixdee of at least $5 up to whatever you beleive fair. Once you've made a donation you can assume the right to use this font for all your following works. If you're a charity or your project is for charitable purposes, please contact us at https://www.dafont.com/profile.php?user=764521
